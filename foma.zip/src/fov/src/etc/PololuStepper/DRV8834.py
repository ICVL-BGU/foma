from gpiozero import OutputDevice, InputDevice
from .BasicStepperDriver import BasicStepperDriver, IS_CONNECTED, PIN_UNCONNECTED

class DRV8834(BasicStepperDriver):
    # Microstep table
    __MAX_MICROSTEP = 32
    _step_high_min = 2
    _step_low_min = 2
    _wakeup_time = 1000

    def __init__(self, steps, dir_pin, step_pin, enable_pin=PIN_UNCONNECTED, m0_pin=PIN_UNCONNECTED, m1_pin=PIN_UNCONNECTED):
        ''' Constructor. Calls BasicStepperDriver constructor'''
        super(DRV8834, self).__init__(steps, dir_pin, step_pin, enable_pin)
        self._m0_pin = OutputDevice(m0_pin) if IS_CONNECTED(m0_pin) else None
        self._m1_pin = OutputDevice(m1_pin) if IS_CONNECTED(m1_pin) else None

    def setMicrostep(self, microsteps):
        ''' Set microstep resolution'''
        super().setMicrostep(microsteps)

        if not self._m0_pin or not self._m1_pin:
            return self._microsteps

        # Set m1_pin based on microsteps
        self._m1_pin.value = (self._microsteps >= 8)

        if self._microsteps in (1, 8):  # Full, 1/8 step
            self._m0_pin.on()
        elif self._microsteps in (2, 16):  # Half, 1/16 step
            self._m0_pin.off()
        elif self._microsteps in (4, 32):  # 1/4, 1/32 step
            if self._m0_pin:
                pin_number = self._m0_pin.pin.number  # Retrieve the BCM pin number before closing
                self._m0_pin.close()  # Close the OutputDevice to release the pin
                self._m0_pin = InputDevice(pin_number)  # Reinitialize as InputDevice with the stored pin number

        return self._microsteps

    def getMaxMicrostep(self):
        ''' Return maximum microstep value'''
        return self.__MAX_MICROSTEP
